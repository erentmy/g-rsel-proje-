﻿//20200305031 Ahmet Eren Tumay

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace StockProgram
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }
        
        private void Main_Load(object sender, EventArgs e)
        {
            DataLogic.BindData("Select * From stock");
        }
        private void AddButton_Click(object sender, EventArgs e)
        {
            DataLogic.Connection.Open();
            var cnn = DataLogic.GetSqlCommand("Insert into stock values(@ProductCode,@ProductName,@ProductType,@ProductQuantity)");

            cnn.Parameters.AddWithValue("@ProductCode", (textBox1.Text));
            cnn.Parameters.AddWithValue("@ProductName", (textBox2.Text));
            cnn.Parameters.AddWithValue("@ProductType", (textBox3.Text));
            cnn.Parameters.AddWithValue("@ProductQuantity", (textBox4.Text));

            cnn.ExecuteNonQuery();
            DataLogic.Connection.Close();

            MessageBox.Show("Data Added Successfully!");
        }

        private void NewButton_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
        }

        private void FindButton_Click(object sender, EventArgs e)
        {
            DataLogic.Connection.Open();
            var cnn = DataLogic.GetSqlCommand("Select * From stock Where product_code=@ProductCode");

            cnn.Parameters.AddWithValue("@ProductCode", (textBox1.Text));

            SqlDataAdapter da = new SqlDataAdapter(cnn);
            DataTable table = new DataTable();
            da.Fill(table);
            dataGridView1.DataSource = table;

            DataLogic.Connection.Close();
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            DataLogic.Connection.Open();

            var cnn = DataLogic.GetSqlCommand("delete from stock where product_code=@ProductCode");
            cnn.Parameters.AddWithValue("@ProductCode", textBox1.Text);
            cnn.ExecuteNonQuery();

            DataLogic.Connection.Close();
            textBox1.Clear();

            MessageBox.Show("Data Deleted Successfully");
        }
    }
}
