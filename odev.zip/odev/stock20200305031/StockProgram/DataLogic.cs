﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StockProgram
{
    internal static class DataLogic
    {
        public static string ConnectionString => @"Data Source=.;Initial Catalog=StockDB;Integrated Security=True";

        private static SqlConnection _connection;
        public static SqlConnection Connection => _connection ??= new SqlConnection(ConnectionString);        
        
        internal static DataTable BindData(string query)
        {
            Connection.Open();
            SqlCommand cnn = new SqlCommand(query, Connection);

            SqlDataAdapter da = new SqlDataAdapter(cnn);
            DataTable table = new DataTable();
            da.Fill(table);

            Connection.Close();

            return table;
        }

        internal static SqlCommand GetSqlCommand(string query)
        {
            return new SqlCommand(query, Connection);
        }
    }
}
