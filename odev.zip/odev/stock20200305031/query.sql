-- CREATE DATABASE StockDB;

USE StockDB;

CREATE TABLE stock (
    product_code VARCHAR(30) PRIMARY KEY,
    product_name VARCHAR(100) NOT NULL,
    product_type VARCHAR(50),
    product_quantity INT NOT NULL
);

INSERT INTO stock (product_code, product_name, product_type, product_quantity)
VALUES
    ('PROD001', 'Laptop', 'Electronics', 10),
    ('PROD002', 'Smartphone', 'Electronics', 20),
    ('PROD003', 'Printer', 'Electronics', 5),
    ('PROD004', 'Desk', 'Furniture', 15),
    ('PROD005', 'Chair', 'Furniture', 20);
